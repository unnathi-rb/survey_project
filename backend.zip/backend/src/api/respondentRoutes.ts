import { Router } from "express";
import { SurveyResponse } from "../domain/SurveyResponse";
import { findSurvey, saveResponse } from "../infrastructure/repositories";
import { sendError } from "./errors";

export const respondentRoutes = Router();

// GET /surveys/:id/form - Get survey form for respondents
respondentRoutes.get("/surveys/:id/form", async (req, res) => {
  try {
    const survey = await findSurvey(req.params.id);
    
    // Missing or draft survey must return 404
    if (!survey || survey.status === "draft") {
      return res.status(404).json({ error: "Survey not found" });
    }
    
    // Closed survey returns 409
    if (survey.status === "closed") {
      return res.status(409).json({ error: "This survey is closed" });
    }

    return res.json(survey.toJSON());
  } catch (error: any) {
    return sendError(res, error);
  }
});

// POST /surveys/:id/responses - Submit answers to a survey
respondentRoutes.post("/surveys/:id/responses", async (req, res) => {
  try {
    const survey = await findSurvey(req.params.id);
    
    if (!survey) {
      return res.status(404).json({ error: "Survey not found" });
    }
    
    // Draft or closed surveys return 409
    if (survey.status === "draft") {
      return res.status(409).json({ error: "Survey is a draft" });
    }
    if (survey.status === "closed") {
      return res.status(409).json({ error: "This survey is closed" });
    }

    const { answers } = req.body;

    if (!Array.isArray(answers)) {
      return res.status(400).json({ error: "Answers must be an array" });
    }

    // Check that every question ID appears only once and exists in the survey
    const questionIds = new Set(survey.questions.map(q => q.id));
    const seenQuestionIds = new Set<string>();

    for (const ans of answers) {
      if (!questionIds.has(ans.questionId)) {
        return res.status(400).json({ error: `Question ID ${ans.questionId} does not exist in this survey` });
      }
      if (seenQuestionIds.has(ans.questionId)) {
        return res.status(400).json({ error: `Question ID ${ans.questionId} appears more than once` });
      }
      seenQuestionIds.add(ans.questionId);
    }

    // Run domain validation rules
    SurveyResponse.validate(survey, answers);

    // Save and return response
    const response = SurveyResponse.create(survey, answers);
    await saveResponse(response);

    return res.status(201).json(response.toJSON());
  } catch (error: any) {
    // Return 400 with the error message listing problems
    return res.status(400).json({ error: error.message });
  }
});