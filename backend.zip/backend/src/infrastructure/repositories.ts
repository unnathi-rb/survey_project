import { SurveyModel, ResponseModel } from "./models";
import { Survey } from "../domain/survey";
import { Question } from "../domain/Question";
import type { SurveyStatus } from "../domain/SurveyStatus";
import type { SurveyResponse } from "../domain/SurveyResponse";

export async function findSurvey(id: string): Promise<Survey | null> {
  const doc = await SurveyModel.findById(id).lean();
  if (!doc) return null;

  return Survey.restore({
    id: doc._id!.toString(),
    title: doc.title ?? "",
    description: doc.description ?? "",
    status: (doc.status as SurveyStatus) ?? "draft",
    questions: (doc.questions || []).map((q: any) =>
      Question.restore({
        id: q.id,
        type: q.type,
        label: q.label,
        helperText: q.helperText ?? "",
        required: q.required ?? true,
        options: (q.options || []).map((o: any) => ({
          id: o.id,
          text: o.text,
          helperText: o.helperText ?? "",
        })),
        maxWords: q.maxWords ?? null,
      })
    ),
    createdAt: doc.createdAt ?? new Date(),
  });
}

export async function saveSurvey(survey: Survey): Promise<void> {
  const data = survey.toJSON();

  await SurveyModel.findByIdAndUpdate(
    data.id,
    {
      title: data.title,
      description: data.description,
      status: data.status,
      questions: data.questions,
      createdAt: data.createdAt,
    },
    { upsert: true, new: true }
  );
}

export async function deleteSurvey(id: string): Promise<void> {
  await SurveyModel.findByIdAndDelete(id);
}

export async function listSurveys(
  statusFilter?: SurveyStatus,
  page: number = 1,
  pageSize: number = 10
): Promise<{ items: Survey[]; total: number }> {
  const query = statusFilter ? { status: statusFilter } : {};
  const skip = (page - 1) * pageSize;

  const [docs, total] = await Promise.all([
    SurveyModel.find(query).sort({ createdAt: -1 }).skip(skip).limit(pageSize).lean(),
    SurveyModel.countDocuments(query),
  ]);

  const items = docs.map((doc: any) =>
    Survey.restore({
      id: doc._id!.toString(),
      title: doc.title ?? "",
      description: doc.description ?? "",
      status: (doc.status as SurveyStatus) ?? "draft",
      questions: (doc.questions || []).map((q: any) =>
        Question.restore({
          id: q.id,
          type: q.type,
          label: q.label,
          helperText: q.helperText ?? "",
          required: q.required ?? true,
          options: (q.options || []).map((o: any) => ({
            id: o.id,
            text: o.text,
            helperText: o.helperText ?? "",
          })),
          maxWords: q.maxWords ?? null,
        })
      ),
      createdAt: doc.createdAt ?? new Date(),
    })
  );

  return { items, total };
}

export async function listResponses(
  surveyId: string,
  page: number = 1,
  pageSize: number = 10
): Promise<{ items: SurveyResponse[]; total: number }> {
  const query = { surveyId };
  const skip = (page - 1) * pageSize;

  const [docs, total] = await Promise.all([
    ResponseModel.find(query).sort({ createdAt: -1 }).skip(skip).limit(pageSize).lean(),
    ResponseModel.countDocuments(query),
  ]);

  return {
    items: docs as unknown as SurveyResponse[],
    total,
  };
}

export async function findAllResponses(surveyId: string): Promise<SurveyResponse[]> {
  const docs = await ResponseModel.find({ surveyId }).lean();
  return docs as unknown as SurveyResponse[];
}
export async function saveResponse(response: SurveyResponse): Promise<void> {
  const data = response.toJSON();
  await ResponseModel.create(data);
}