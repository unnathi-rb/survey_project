import { randomUUID } from "node:crypto";
import type { QuestionType } from "./Questiontype";
import { Option } from "./option";

export function countWords(text: string): number {
  const trimmed = text.trim();
  return trimmed === "" ? 0 : trimmed.split(/\s+/).length;
}

export function checkWordLimit(text: string, maxWords: number | null): boolean {
  if (maxWords === null) return true;
  return countWords(text) <= maxWords;
}

export interface QuestionChanges {
  label?: string;
  helperText?: string;
  required?: boolean;
  maxWords?: number | null;
}

export class Question {
  readonly id: string;
  private _type: QuestionType;
  private _label: string = "";
  private _helperText: string = "";
  private _required: boolean = true;
  private _options: Option[] = [];
  private _maxWords: number | null = null;

  constructor(
    data: {
      type: QuestionType;
      label: string;
      helperText?: string;
      required?: boolean;
      options?: Option[];
      maxWords?: number | null;
    },
    restoredId?: string
  ) {
    this.id = restoredId ?? randomUUID();
    this._type = data.type;
    this.setLabel(data.label);
    this._helperText = data.helperText ?? "";
    this._required = data.required ?? true;
    this._options = [...(data.options ?? [])];
    this._maxWords = data.maxWords ?? null;
  }

  get type(): QuestionType { return this._type; }
  get label(): string { return this._label; }
  get helperText(): string { return this._helperText; }
  get required(): boolean { return this._required; }
  get maxWords(): number | null { return this._maxWords; }
  
  get options(): readonly Option[] {
    return Object.freeze(this._options.map(o => Option.restore(o.toJSON())));
  }

  private isChoiceType(): boolean {
    return this._type === "single_choice" || this._type === "multiple_choice";
  }

  setLabel(label: string): void {
    const value = label.trim();
    if (!value) {
      throw new Error("Question label cannot be blank");
    }
    this._label = value;
  }

  update(changes: QuestionChanges): void {
    if (changes.label !== undefined) {
      this.setLabel(changes.label);
    }
    if (changes.helperText !== undefined) {
      this._helperText = changes.helperText;
    }
    if (changes.required !== undefined) {
      this._required = changes.required;
    }
    if (changes.maxWords !== undefined) {
      if (this._type !== "short_text" && this._type !== "long_text") {
        throw new Error("Only text questions can have a word limit");
      }
      if (changes.maxWords !== null) {
        if (changes.maxWords <= 0 || !Number.isInteger(changes.maxWords)) {
          throw new Error("Word limit must be a positive whole number");
        }
      }
      this._maxWords = changes.maxWords;
    }
  }

  addOption(text: string, helperText?: string): Option {
    if (!this.isChoiceType()) {
      throw new Error("Only choice questions can have options");
    }
    const option = new Option(randomUUID(), text, helperText);
    this._options.push(option);
    return Option.restore(option.toJSON());
  }

  removeOption(optionId: string): void {
    if (!this.isChoiceType()) {
      throw new Error("Only choice questions can have options");
    }
    const index = this._options.findIndex(o => o.id === optionId);
    if (index === -1) {
      throw new Error("Option not found");
    }
    this._options.splice(index, 1);
  }

  updateOption(optionId: string, changes: { text?: string; helperText?: string } | string): void {
    if (!this.isChoiceType()) {
      throw new Error("Only choice questions can have options");
    }
    const option = this._options.find(o => o.id === optionId);
    if (!option) {
      throw new Error("Option not found");
    }
    if (typeof changes === "string") {
      option.setText(changes);
    } else {
      option.update(changes);
    }
  }

  findProblems(): string[] {
    const problems: string[] = [];
    if (!this._label.trim()) {
      problems.push("Question label cannot be blank");
    }
    if (this.isChoiceType() && this._options.length < 2) {
      problems.push("Choice questions need at least two options");
    }
    return problems;
  }

  toJSON() {
    return {
      id: this.id,
      type: this._type,
      label: this._label,
      helperText: this._helperText,
      required: this._required,
      options: this._options.map(o => o.toJSON()),
      maxWords: this._maxWords,
    };
  }

  static restore(data: {
    id: string;
    type: QuestionType;
    label: string;
    helperText?: string;
    required?: boolean;
    options?: { id: string; text: string; helperText?: string }[];
    maxWords?: number | null;
  }): Question {
    return new Question(
      {
        type: data.type,
        label: data.label,
        helperText: data.helperText,
        required: data.required,
        options: (data.options || []).map(o => Option.restore(o)),
        maxWords: data.maxWords,
      },
      data.id
    );
  }
}