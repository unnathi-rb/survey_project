import { randomUUID } from "node:crypto";
import { Survey } from "./survey";
import { countWords } from "./Question";

export type Answer = {
  questionId: string;
  value: string | string[] | number;
};

export class SurveyResponse {
  readonly id: string;
  readonly surveyId: string;
  readonly answers: Answer[];
  readonly createdAt: Date;

  constructor(
    surveyId: string,
    answers: Answer[],
    restored?: { id?: string; createdAt?: Date }
  ) {
    this.id = restored?.id ?? randomUUID();
    this.surveyId = surveyId;
    this.answers = answers;
    this.createdAt = restored?.createdAt ?? new Date();
  }

  static create(
    survey: Survey,
    answers: Answer[],
    createdAt?: Date
  ): SurveyResponse {
    SurveyResponse.validate(survey, answers);
    return new SurveyResponse(survey.id, answers, { createdAt });
  }

  static validate(survey: Survey, answers: Answer[]): void {
    // 1. Check survey status requirements matching tests
    if (survey.status === "draft") {
      throw new Error("Survey is a draft and not available yet");
    }
    if (survey.status === "closed") {
      throw new Error("This survey is closed");
    }

    const questionMap = new Map(survey.questions.map((q) => [q.id, q]));
    const answeredQuestionIds = new Set<string>();
    const answerMap = new Map<string, string | string[] | number>();

    // 2. Validate answer structures, duplicates, and unknown questions
    for (const ans of answers) {
      if (!questionMap.has(ans.questionId)) {
        throw new Error("Unknown question");
      }
      if (answeredQuestionIds.has(ans.questionId)) {
        throw new Error("Question answered more than once");
      }
      answeredQuestionIds.add(ans.questionId);
      answerMap.set(ans.questionId, ans.value);
    }

    // 3. Validate each question's answer against constraints
    for (const question of survey.questions) {
      const val = answerMap.get(question.id);
      const isEmpty =
        val === undefined ||
        val === null ||
        val === "" ||
        (Array.isArray(val) && val.length === 0);

      if (question.required && isEmpty) {
        throw new Error(`Question "${question.label}" is required`);
      }

      if (!isEmpty && val !== undefined) {
        if (
          question.type === "single_choice" ||
          question.type === "multiple_choice"
        ) {
          const validOptionIds = new Set(question.options.map((o: any) => o.id));
          if (question.type === "single_choice") {
            if (typeof val !== "string" || !validOptionIds.has(val)) {
              throw new Error("Option is not a valid option");
            }
          } else {
            if (
              !Array.isArray(val) ||
              val.some((v) => typeof v !== "string" || !validOptionIds.has(v))
            ) {
              throw new Error("Invalid options selected");
            }
          }
        } else if (question.type === "rating") {
          if (
            typeof val !== "number" ||
            !Number.isInteger(val) ||
            val < 1 ||
            val > 5
          ) {
            throw new Error("Rating must be a number between 1 and 5");
          }
        } else if (
          question.type === "short_text" ||
          question.type === "long_text"
        ) {
          if (typeof val !== "string") {
            throw new Error("Answer must be text");
          }
          if (question.maxWords !== null) {
            const wordCount = countWords(val);
            if (wordCount > question.maxWords) {
              throw new Error(
                `at most ${question.maxWords} words (you wrote ${wordCount})`
              );
            }
          }
        }
      }
    }
  }

  toJSON() {
    return {
      id: this.id,
      surveyId: this.surveyId,
      answers: this.answers,
      createdAt: this.createdAt,
    };
  }

  static restore(data: {
    id: string;
    surveyId: string;
    answers: Answer[];
    createdAt: Date;
  }): SurveyResponse {
    return new SurveyResponse(data.surveyId, data.answers, {
      id: data.id,
      createdAt: data.createdAt,
    });
  }
}